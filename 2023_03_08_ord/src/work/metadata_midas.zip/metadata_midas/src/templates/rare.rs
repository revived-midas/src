use super::*;

#[derive(Boilerplate)]
pub(crate) struct RareTxt(pub(crate) Vec<(Sat, SatPoint)>);
