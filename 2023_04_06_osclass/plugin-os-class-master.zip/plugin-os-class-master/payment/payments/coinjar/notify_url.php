<?php

    CoinjarPayment::processPayment();

?>